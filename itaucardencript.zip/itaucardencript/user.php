<?php
header("Location: Painel/");
?>